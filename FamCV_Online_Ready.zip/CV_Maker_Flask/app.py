import os
import sqlite3
import uuid
from functools import wraps
from io import BytesIO
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_RIGHT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "cvmaker.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "private_uploads")
PROFILE_UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(PROFILE_UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key-before-deployment")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

TRANSLATIONS = {
    "en": {"home":"Build a CV that opens doors", "subtitle":"Create a polished resume in minutes.", "create":"Create your CV", "my_cvs":"My CVs", "login":"Log in", "register":"Create account", "logout":"Log out", "name":"Full name", "email":"Email", "password":"Password", "title":"Professional title", "phone":"Phone", "location":"Location", "summary":"Professional summary", "experience":"Work experience", "education":"Education", "skills":"Skills", "languages":"Languages", "template":"Template", "save":"Save CV", "preview":"Preview CV", "download":"Download PDF", "upload":"Upload existing CV (PDF)", "upload_btn":"Upload PDF", "saved":"CV saved.", "delete":"Delete", "edit":"Edit", "no_cvs":"No CVs yet. Create your first one!", "dashboard":"Dashboard", "login_required":"Please log in first.", "uploaded":"PDF uploaded successfully.", "photo":"Profile photo", "back":"Back", "register_hint":"Create an account to save and manage CVs."},
    "ku": {"home":"CV ـێکی پڕۆفیشناڵ دروست بکە", "subtitle":"لە چەند خولەکێکدا CV ـێکی جوان ئامادە بکە.", "create":"دروستکردنی CV", "my_cvs":"CV ـەکانم", "login":"چوونەژوورەوە", "register":"دروستکردنی هەژمار", "logout":"چوونەدەرەوە", "name":"ناوی تەواو", "email":"ئیمەیڵ", "password":"وشەی نهێنی", "title":"ناونیشانی پیشەیی", "phone":"ژمارەی تەلەفۆن", "location":"شوێن", "summary":"پوختەی پیشەیی", "experience":"ئەزموونی کار", "education":"خوێندن", "skills":"تواناکان", "languages":"زمانەکان", "template":"قاڵب", "save":"پاشەکەوتکردنی CV", "preview":"پێشبینینی CV", "download":"داگرتنی PDF", "upload":"Upload کردنی CV ـی کۆن (PDF)", "upload_btn":"Upload کردنی PDF", "saved":"CV پاشەکەوت کرا.", "delete":"سڕینەوە", "edit":"دەستکاریکردن", "no_cvs":"هێشتا CV ـت نییە. یەکەم CV دروست بکە!", "dashboard":"بەڕێوەبردن", "login_required":"تکایە سەرەتا بچۆ ژوورەوە.", "uploaded":"PDF بە سەرکەوتوویی Upload کرا.", "photo":"وێنەی پڕۆفایل", "back":"گەڕانەوە", "register_hint":"هەژمارێک دروست بکە بۆ پاشەکەوتکردن و بەڕێوەبردنی CV."},
    "ar": {"home":"أنشئ سيرة ذاتية احترافية", "subtitle":"أنشئ سيرة ذاتية أنيقة خلال دقائق.", "create":"إنشاء السيرة الذاتية", "my_cvs":"سيرتي الذاتية", "login":"تسجيل الدخول", "register":"إنشاء حساب", "logout":"تسجيل الخروج", "name":"الاسم الكامل", "email":"البريد الإلكتروني", "password":"كلمة المرور", "title":"المسمى المهني", "phone":"الهاتف", "location":"الموقع", "summary":"الملخص المهني", "experience":"الخبرة العملية", "education":"التعليم", "skills":"المهارات", "languages":"اللغات", "template":"القالب", "save":"حفظ السيرة", "preview":"معاينة السيرة", "download":"تنزيل PDF", "upload":"رفع سيرة موجودة (PDF)", "upload_btn":"رفع PDF", "saved":"تم حفظ السيرة الذاتية.", "delete":"حذف", "edit":"تعديل", "no_cvs":"لا توجد سير ذاتية بعد. أنشئ أول واحدة!", "dashboard":"لوحة التحكم", "login_required":"يرجى تسجيل الدخول أولاً.", "uploaded":"تم رفع ملف PDF بنجاح.", "photo":"الصورة الشخصية", "back":"رجوع", "register_hint":"أنشئ حساباً لحفظ السير الذاتية وإدارتها."}
}

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with get_db() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        db.execute("""CREATE TABLE IF NOT EXISTS cvs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            title TEXT NOT NULL DEFAULT 'My CV', data TEXT NOT NULL,
            uploaded_pdf TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)""")

def current_lang():
    lang = request.args.get("lang") or session.get("lang") or "en"
    if lang not in TRANSLATIONS:
        lang = "en"
    session["lang"] = lang
    return lang

@app.context_processor
def inject_globals():
    lang = current_lang()
    return {"t": TRANSLATIONS[lang], "lang": lang, "direction": "rtl" if lang in ("ku", "ar") else "ltr"}

@app.template_filter("fromjson")
def fromjson_filter(value):
    import json
    try: return json.loads(value or "{}")
    except (ValueError, TypeError): return {}

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash(TRANSLATIONS[current_lang()]["login_required"], "error")
            return redirect(url_for("login", lang=current_lang()))
        return view(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/set-language/<lang>")
def set_language(lang):
    if lang not in TRANSLATIONS: abort(404)
    session["lang"] = lang
    return redirect(request.referrer or url_for("index"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter your name, a valid email, and a password of at least 8 characters.", "error")
        else:
            try:
                with get_db() as db:
                    cur = db.execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                                     (name, email, generate_password_hash(password)))
                    session["user_id"] = cur.lastrowid
                    session["user_name"] = name
                return redirect(url_for("dashboard", lang=current_lang()))
            except sqlite3.IntegrityError:
                flash("An account with that email already exists.", "error")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            return redirect(url_for("dashboard", lang=current_lang()))
        flash("Email or password is incorrect.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    with get_db() as db:
        cvs = db.execute("SELECT * FROM cvs WHERE user_id=? ORDER BY updated_at DESC", (session["user_id"],)).fetchall()
    return render_template("dashboard.html", cvs=cvs)

@app.route("/cv/new", methods=["GET", "POST"])
@app.route("/cv/<int:cv_id>/edit", methods=["GET", "POST"])
@login_required
def edit_cv(cv_id=None):
    cv = None
    data = {}
    if cv_id is not None:
        with get_db() as db:
            cv = db.execute("SELECT * FROM cvs WHERE id=? AND user_id=?", (cv_id, session["user_id"])).fetchone()
        if not cv: abort(404)
        import json
        data = json.loads(cv["data"])
    if request.method == "POST":
        import json
        fields = ["full_name", "professional_title", "email", "phone", "location", "summary", "experience", "education", "skills", "languages", "template"]
        data = {field: request.form.get(field, "").strip() for field in fields}
        previous_data = {}
        if cv:
            import json as _json
            previous_data = _json.loads(cv["data"])
        data["template"] = data.get("template") if data.get("template") in ("modern", "classic", "minimal") else "modern"
        data["photo"] = previous_data.get("photo", "")
        photo = request.files.get("photo")
        if photo and photo.filename:
            ext = photo.filename.rsplit(".", 1)[-1].lower() if "." in photo.filename else ""
            if ext not in ALLOWED_IMAGE_EXTENSIONS:
                flash("Photo must be PNG, JPG, JPEG, or WEBP.", "error")
                return render_template("editor.html", cv=cv, data=data)
            filename = f"{uuid.uuid4().hex}.{ext}"
            photo.save(os.path.join(PROFILE_UPLOAD_DIR, filename))
            data["photo"] = f"uploads/{filename}"
        title = data.get("professional_title") or data.get("full_name") or "My CV"
        payload = json.dumps(data, ensure_ascii=False)
        with get_db() as db:
            if cv:
                db.execute("UPDATE cvs SET title=?, data=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?",
                           (title, payload, cv_id, session["user_id"]))
            else:
                db.execute("INSERT INTO cvs(user_id,title,data) VALUES(?,?,?)", (session["user_id"], title, payload))
        flash(TRANSLATIONS[current_lang()]["saved"], "success")
        return redirect(url_for("dashboard", lang=current_lang()))
    return render_template("editor.html", cv=cv, data=data)

@app.route("/cv/<int:cv_id>/delete", methods=["POST"])
@login_required
def delete_cv(cv_id):
    with get_db() as db:
        db.execute("DELETE FROM cvs WHERE id=? AND user_id=?", (cv_id, session["user_id"]))
    flash("CV deleted.", "success")
    return redirect(url_for("dashboard", lang=current_lang()))

@app.route("/cv/upload", methods=["POST"])
@login_required
def upload_cv():
    f = request.files.get("pdf")
    if not f or not f.filename:
        flash("Choose a PDF file first.", "error")
        return redirect(url_for("dashboard", lang=current_lang()))
    if not f.filename.lower().endswith(".pdf"):
        flash("Only PDF files are allowed.", "error")
        return redirect(url_for("dashboard", lang=current_lang()))
    raw = f.read(8)
    if not raw.startswith(b"%PDF-"):
        flash("The selected file is not a valid PDF.", "error")
        return redirect(url_for("dashboard", lang=current_lang()))
    f.stream.seek(0)
    safe_name = secure_filename(f.filename)[:100] or "uploaded.pdf"
    filename = f"{uuid.uuid4().hex}_{safe_name}"
    f.save(os.path.join(UPLOAD_DIR, filename))
    import json
    data = {"uploaded_only": True, "uploaded_name": safe_name, "template": "modern"}
    with get_db() as db:
        db.execute("INSERT INTO cvs(user_id,title,data,uploaded_pdf) VALUES(?,?,?,?)",
                   (session["user_id"], safe_name, json.dumps(data), filename))
    flash(TRANSLATIONS[current_lang()]["uploaded"], "success")
    return redirect(url_for("dashboard", lang=current_lang()))


@app.route("/cv/<int:cv_id>/uploaded")
@login_required
def view_uploaded_pdf(cv_id):
    with get_db() as db:
        cv = db.execute("SELECT * FROM cvs WHERE id=? AND user_id=?", (cv_id, session["user_id"])).fetchone()
    if not cv or not cv["uploaded_pdf"]:
        abort(404)
    private_path = os.path.join(UPLOAD_DIR, cv["uploaded_pdf"])
    if not os.path.isfile(private_path):
        abort(404)
    return send_file(private_path, as_attachment=False, download_name=os.path.basename(cv["title"]), mimetype="application/pdf")

@app.route("/cv/<int:cv_id>/pdf")
@login_required
def download_pdf(cv_id):
    import json
    with get_db() as db:
        cv = db.execute("SELECT * FROM cvs WHERE id=? AND user_id=?", (cv_id, session["user_id"])).fetchone()
    if not cv: abort(404)
    if cv["uploaded_pdf"]:
        private_path = os.path.join(UPLOAD_DIR, cv["uploaded_pdf"])
        if not os.path.isfile(private_path): abort(404)
        return send_file(private_path, as_attachment=True, download_name=os.path.basename(cv["title"]), mimetype="application/pdf")
    data = json.loads(cv["data"])
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=48, leftMargin=48, topMargin=48, bottomMargin=42)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="CVName", parent=styles["Title"], fontSize=24, leading=28, textColor=colors.HexColor("#153e75"), spaceAfter=4))
    styles.add(ParagraphStyle(name="CVSection", parent=styles["Heading2"], fontSize=12, leading=16, textColor=colors.HexColor("#2563eb"), spaceBefore=13, spaceAfter=5))
    styles.add(ParagraphStyle(name="CVBody", parent=styles["BodyText"], fontSize=9.5, leading=14, spaceAfter=4))
    story = []
    def safe(v):
        from xml.sax.saxutils import escape
        return escape(v or "").replace("\n", "<br/>")
    story.append(Paragraph(safe(data.get("full_name") or "Your Name"), styles["CVName"]))
    story.append(Paragraph(safe(data.get("professional_title")), styles["Heading3"]))
    contact = "  |  ".join(x for x in [data.get("email"), data.get("phone"), data.get("location")] if x)
    if contact: story.append(Paragraph(safe(contact), styles["CVBody"]))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#dbeafe"), spaceBefore=8, spaceAfter=8))
    for key, heading in [("summary","PROFESSIONAL SUMMARY"),("experience","WORK EXPERIENCE"),("education","EDUCATION"),("skills","SKILLS"),("languages","LANGUAGES")]:
        value = data.get(key, "")
        if value:
            story.append(Paragraph(heading, styles["CVSection"]))
            story.append(Paragraph(safe(value), styles["CVBody"]))
    doc.build(story)
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name="my-cv.pdf", mimetype="application/pdf")

@app.errorhandler(413)
def too_large(_error):
    flash("File too large. Maximum upload size is 5 MB.", "error")
    return redirect(url_for("dashboard", lang=current_lang()))

init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1", host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
