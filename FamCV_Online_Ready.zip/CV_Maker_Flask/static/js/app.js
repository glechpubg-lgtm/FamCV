document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("cv-form");
  const preview = document.getElementById("cv-preview");
  if (!form || !preview) return;
  const fallbacks = {
    full_name: "Your Name", professional_title: "Professional Title",
    email: "hello@email.com", phone: "+1 555 0100", location: "City, Country",
    summary: "Add your professional summary here...", experience: "Add your work experience here...",
    education: "Add your education here...", skills: "Add your skills here...", languages: "Add your languages here..."
  };
  form.querySelectorAll("[data-preview]").forEach(input => {
    const update = () => {
      const target = preview.querySelector(`[data-target="${input.dataset.preview}"]`);
      if (target) target.textContent = input.value.trim() || fallbacks[input.dataset.preview] || "";
    };
    input.addEventListener("input", update);
    update();
  });
  const template = document.getElementById("template-select");
  if (template) {
    const applyTemplate = () => {
      preview.classList.remove("template-modern", "template-classic", "template-minimal");
      preview.classList.add(`template-${template.value}`);
    };
    template.addEventListener("change", applyTemplate);
    applyTemplate();
  }
  const photoInput = form.querySelector('input[name="photo"]');
  if (photoInput) photoInput.addEventListener("change", () => {
    const file = photoInput.files && photoInput.files[0];
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
      alert("Choose a PNG, JPG, or WEBP image.");
      photoInput.value = "";
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert("Image must be smaller than 5 MB.");
      photoInput.value = "";
      return;
    }
    const img = document.createElement("img");
    img.alt = "Profile preview";
    img.src = URL.createObjectURL(file);
    const holder = preview.querySelector(".preview-photo");
    if (holder) { holder.replaceChildren(img); }
  });
});
