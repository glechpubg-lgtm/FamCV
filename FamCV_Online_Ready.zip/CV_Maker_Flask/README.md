# CV Maker — Python + Flask

A responsive CV builder with Kurdish, Arabic, and English UI, account registration/login, saved CVs, PDF export, and PDF upload.

## Run in Visual Studio Code (Windows)

1. Install Python 3.10+ and the VS Code Python extension.
2. Open this folder in VS Code.
3. Open Terminal → New Terminal and run:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   python app.py
   ```

4. Open http://127.0.0.1:5000

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that terminal, then activate again. Or use `\.venv\Scripts\python.exe -m pip install -r requirements.txt` and `\.venv\Scripts\python.exe app.py`.

## Features

- Register/login with password hashes
- Store CV data in SQLite, per user
- Three visual templates in live preview
- Download generated PDF
- Upload an existing PDF (maximum 5 MB)
- UI language switch: English, Kurdish, Arabic
- Responsive layout

## Deploy online

Deploy on a Python-compatible host (for example Render, Railway, or a VPS):
- Build/install command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app` (install `gunicorn` on Linux with `pip install gunicorn`)
- Set `SECRET_KEY` to a long random secret and set `FLASK_DEBUG=0`.
- Use persistent storage for `cvmaker.db` and `static/uploads`, or configure a managed database/object storage.
- Set HTTPS and a secure session-cookie configuration at the host/proxy level.
- Never deploy with Flask debug mode enabled.

Uploaded PDFs are stored in `private_uploads` and served through an ownership-checked route. Profile photos are stored in `static/uploads`; for production, consider private object storage if profile photos should not be public. Add CSRF protection, email verification, rate limiting, and malware scanning before production use.

## Notes

- The uploaded PDF is stored as a file; this starter does not extract its text into editable fields.
- PDF export currently uses ReportLab's built-in fonts. Arabic/Kurdish shaping and RTL output may need an embedded Unicode font and shaping support for perfect PDF typography; the web preview supports RTL direction.


## Publish FamCV online (public link)

This project includes a `Procfile`, `render.yaml`, and Gunicorn so it can be deployed as a web service. To publish it, upload the project folder to a GitHub repository, then create a new Web Service on Render and connect that repository. Render can use the included `render.yaml`; the start command is `gunicorn app:app`. Set `SECRET_KEY` to a strong secret in the hosting dashboard if you configure it manually.

**Important:** the app currently stores users, CV records, and uploaded files on the local filesystem using SQLite. On hosting plans with an ephemeral filesystem, that data can be lost on redeploy/restart. For a real public service, configure persistent storage or migrate to a managed database and persistent file storage before relying on it for important CVs. Do not commit `.env` or private user data to GitHub.
